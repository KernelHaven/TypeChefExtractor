package de.fosd.typechef

/**
 * Created by IntelliJ IDEA.
 * User: kaestner
 * Date: 29.12.11
 * Time: 15:34
 * To change this template use File | Settings | File Templates.
 */

trait VersionInfo {
    def getVersion: String
}