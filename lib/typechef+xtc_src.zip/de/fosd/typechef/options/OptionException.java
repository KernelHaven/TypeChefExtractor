package de.fosd.typechef.options;


public class OptionException extends RuntimeException {
    public OptionException(String s) {
        super(s);
    }
}
