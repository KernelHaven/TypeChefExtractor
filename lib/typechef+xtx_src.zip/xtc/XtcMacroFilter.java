package xtc;

/**
 * User: ckaestne
 * Date: 2/20/13
 * Time: 6:25 PM
 * use filter concept from TypeChef
 */
public interface XtcMacroFilter {
    boolean isVariable(String macroName);
}
