#ifndef _AGENT_CLASS_H_
#define _AGENT_CLASS_H_
extern const signed char class_agent[716];
extern const signed char class_agent_jni_assertion_failure[809];
extern const signed char class_agent_variable[4564];
#endif /* _AGENT_CLASS_H_ */
